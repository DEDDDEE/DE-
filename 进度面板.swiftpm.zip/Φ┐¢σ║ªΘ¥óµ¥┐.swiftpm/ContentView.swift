// 小缤的人生绿点进度 App - 多模块基础结构

import SwiftUI
import UIKit

// 每个进度模块的数据结构
struct DotModule: Identifiable {
    let id = UUID()
    var title: String
    var icon: String
    var startDate: Date
    var endDate: Date
    var color: Color
    var isSpecial: Bool = false
}

// 条形时间轴视图
struct TimelineBarView: View {
    let module: DotModule
    var totalDuration: Double {
        module.endDate.timeIntervalSince(module.startDate)
    }
    var progress: Double {
        min(Date().timeIntervalSince(module.startDate), totalDuration)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(module.icon)
                Text(module.title)
                    .foregroundColor(.white)
                    .font(.headline)
                Spacer()
                Text("\(Int(progress / totalDuration * 100))%")
                    .foregroundColor(.gray)
                    .font(.subheadline)
            }
            ZStack(alignment: .leading) {
                Capsule()
                    .fill(Color.gray.opacity(0.3))
                    .frame(height: 10)
                Capsule()
                    .fill(module.color)
                    .frame(width: CGFloat(progress / totalDuration) * UIScreen.main.bounds.width * 0.85, height: 10)
            }
        }
        .padding()
        .background(Color.black)
        .cornerRadius(12)
    }
}

// 核心组件：单个模块的圆点进度图
struct DotProgressView: View {
    let module: DotModule
    @State private var isPulsing = false
    
    var totalDays: Int {
        Calendar.current.dateComponents([.day], from: module.startDate, to: module.endDate).day ?? 1
    }
    
    var daysPassed: Int {
        Calendar.current.dateComponents([.day], from: module.startDate, to: Date()).day ?? 0
    }
    
    let columns = 25
    
    var body: some View {
        let _ = DispatchQueue.main.async {
            if module.isSpecial {
                isPulsing = true
            }
        }
        VStack(alignment: .leading, spacing: 12) {
            // 标题行 + 圆环
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 8) {
                        Text(module.icon)
                        Text(module.title)
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                }
                Spacer()
                ZStack {
                    Circle()
                        .stroke(Color.gray.opacity(0.3), lineWidth: 5)
                        .frame(width: 48, height: 48)
                    Circle()
                        .trim(from: 0, to: CGFloat(min(Double(daysPassed) / Double(totalDays), 1.0)))
                        .stroke(module.color, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .frame(width: 48, height: 48)
                    Text("\(Int(Double(daysPassed) / Double(totalDays) * 100))%")
                        .font(.caption)
                        .foregroundColor(.white)
                }
            }
            
            // 圆点网格
            LazyVGrid(columns: Array(repeating: GridItem(.fixed(10), spacing: 4), count: columns), spacing: 4) {
                ForEach(0..<totalDays, id: \.self) { day in
                    
                    if module.isSpecial && day == daysPassed - 1 {
                        Circle()
                            .frame(width: 10, height: 10)
                            .foregroundColor(module.color)
                            .scaleEffect(isPulsing ? 1.4 : 1.0)
                            .shadow(color: module.color.opacity(0.8), radius: 4, x: 0, y: 0)
                            .animation(.easeInOut(duration: 1).repeatForever(autoreverses: true), value: isPulsing)
                    } else {
                        Circle()
                            .frame(width: 10, height: 10)
                            .foregroundColor(day < daysPassed ? module.color : Color(.sRGB, red: 0.1, green: 0.2, blue: 0.1))
                    }
                }
            }
            
            // 底部信息
            Text("\(daysPassed)/\(totalDays)  ·  \(String(format: "%.2f", Double(daysPassed)/Double(totalDays)*100))%")
                .font(.subheadline)
                .foregroundColor(.gray)
        }
        .padding()
        .background(Color.black)
        .cornerRadius(16)
    }
}

// 模块编辑视图
struct EditModuleView: View {
    @Binding var module: DotModule
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("名称 & 图标")) {
                    TextField("标题", text: $module.title)
                    TextField("图标", text: $module.icon)
                }
                
                Section(header: Text("时间范围")) {
                    DatePicker("开始日期", selection: $module.startDate, displayedComponents: .date)
                    DatePicker("结束日期", selection: $module.endDate, displayedComponents: .date)
                }
                
                Section(header: Text("颜色")) {
                    ColorPicker("选择颜色", selection: $module.color)
                }
                
                Section(header: Text("特殊模块")) {
                    Toggle("是否呼吸闪烁", isOn: $module.isSpecial)
                }
            }
            .navigationTitle("编辑模块")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") {
                        dismiss()
                    }
                }
            }
        }
    }
}

// 主界面：多个模块的组合
struct ContentView: View {
    @Environment(\.colorScheme) var colorScheme
    @State private var showShareSheet = false
    @State private var imageToShare: UIImage? = nil
    @State var modules: [DotModule] = [
        DotModule(title: "年度进度", icon: "📅", startDate: Calendar.current.date(from: DateComponents(year: 2025, month: 1, day: 1))!, endDate: Calendar.current.date(from: DateComponents(year: 2026, month: 1, day: 1))!, color: .green),
        DotModule(title: "新西兰WHV", icon: "🇳🇿", startDate: Calendar.current.date(from: DateComponents(year: 2024, month: 12, day: 20))!, endDate: Calendar.current.date(from: DateComponents(year: 2026, month: 3, day: 20))!, color: .purple),
        DotModule(title: "复仇计划", icon: "⚔️", startDate: Calendar.current.date(from: DateComponents(year: 2025, month: 3, day: 10))!, endDate: Calendar.current.date(from: DateComponents(year: 2025, month: 9, day: 10))!, color: .red, isSpecial: true)
    ]
    
    @State private var showAddSheet = false
    
    var body: some View {
        NavigationView {
            List {
                ForEach(modules.indices, id: \.self) { index in
                    SwipeToDeleteView {
                        NavigationLink(destination: EditModuleView(module: $modules[index])) {
                            DotProgressView(module: modules[index])
                        }
                    } onDelete: {
                        modules.remove(at: index)
                    }
                }
                .onMove { indices, newOffset in
                    modules.move(fromOffsets: indices, toOffset: newOffset)
                }
            }
            .listStyle(.plain)
            .navigationTitle("进度面板")
            .toolbar {
                EditButton()
                Button(action: { showAddSheet = true }) {
                    Image(systemName: "plus")
                }
            }
            .sheet(isPresented: $showAddSheet) {
                
            }
            .sheet(isPresented: $showShareSheet) {
                if let image = imageToShare {
                    ShareSheet(activityItems: [image])
                }
            }
        }
        .background(Color.black.edgesIgnoringSafeArea(.all))
    }
}

// 预览
// 分享用封装组件
struct ShareSheet: UIViewControllerRepresentable {
    var activityItems: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

// 支持左滑删除的视图容器
struct SwipeToDeleteView<Content: View>: View {
    var content: () -> Content
    var onDelete: () -> Void
    
    var body: some View {
        content()
            .swipeActions(edge: .trailing) {
                Button(role: .destructive, action: onDelete) {
                    Label("删除", systemImage: "trash")
                }
            }
    }
}

// 导出模块截图功能
extension ContentView {
    func exportFirstModule() {
        guard let window = UIApplication.shared.windows.first else { return }
        let controller = UIHostingController(rootView: DotProgressView(module: modules.first!))
        controller.view.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
        window.rootViewController?.view.addSubview(controller.view)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            let renderer = UIGraphicsImageRenderer(size: controller.view.bounds.size)
            let image = renderer.image { ctx in
                controller.view.drawHierarchy(in: controller.view.bounds, afterScreenUpdates: true)
            }
            controller.view.removeFromSuperview()
            imageToShare = image
            showShareSheet = true
        }
    }
}
